﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MediCareApp
{
    public partial class FormDocQueue : Form
    {
        public FormDocQueue()
        {
            InitializeComponent();
        }

        private void customImageButton5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
